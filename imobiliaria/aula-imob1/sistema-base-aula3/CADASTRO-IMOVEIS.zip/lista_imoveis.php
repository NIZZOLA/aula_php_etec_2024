<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Imóveis</title>
</head>
<body>
    <h1>Imóveis</h1>
    <a href="cadastrar_imovel.php">Incluir novo</a>



</body>
</html>
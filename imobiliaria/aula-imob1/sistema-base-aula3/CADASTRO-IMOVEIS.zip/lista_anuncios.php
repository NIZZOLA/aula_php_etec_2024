<h1>Anúncios</h1>

<a href="cadastrar_anuncio.php">Incluir novo</a>

<?php
?>
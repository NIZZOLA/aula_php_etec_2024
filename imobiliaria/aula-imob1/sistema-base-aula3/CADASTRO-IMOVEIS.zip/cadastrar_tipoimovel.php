<!DOCTYPE html>
<html>
<head>
    <title>Cadastrar Usuário</title>
</head>
<body>
    <h1>Cadastrar Tipo de Imóvel</h1>
    <form method="post" action="gravar_tipoimovel.php">
        <label>Tipo de imóvel:</label>
        <input type="text" name="tipo" required><br><br>
        
        <input type="submit" value="Cadastrar">
    </form>
</body>
</html>